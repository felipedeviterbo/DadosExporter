﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosExporter
{
    public static class Consts
    {
        public const string ArquivoConfiguracaoRelatorio = nameof(ArquivoConfiguracaoRelatorio);
    }
}
