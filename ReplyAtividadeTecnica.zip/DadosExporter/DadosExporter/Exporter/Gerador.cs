﻿using DadosExporter.Models;
using DadosExporter.Repositorios;
using log4net;
using Quartz;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using DadosExporter.Context;
using DadosExporter.Services;

namespace DadosExporter.Exporter
{
    public class Gerador : IJob
    {
        private readonly EventosWindowsLogger Log;
        private RelatoriosRepository RelatoriosRepository { get; set; }
        private Relatorio relatorio { get; set; }

        public Gerador()
        {
            RelatoriosRepository = new RelatoriosRepository();
            Log = new EventosWindowsLogger();
        }

        public void Execute(IJobExecutionContext context)
        {
            try
            {
                relatorio = RelatoriosRepository.FindRelatorioByKey(context.Trigger.Key.Name);
                if (relatorio == null) throw new InvalidOperationException($"Relatório não definido chave {context.Trigger.Key.Name}");
                GerarRelatorio();
            }
            catch (Exception ex)
            {
                Log.AddError($@"Erro gerar relatorio {relatorio.Name}", ex);
            }
        }

        public void GerarRelatorio()
        {
            var connectionString = ConfigurationManager.ConnectionStrings[Consts.GeradorRelatorioConnection].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(relatorio.GetSqlRelatorio(), connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                GerarArquivoCsv(reader);
                reader.Close();
            }
            SalvarGeracaoArquivo();
        }

        public void GerarArquivoCsv(SqlDataReader reader)
        {
            string caminho = relatorio.GetCSVPathDestino();
            using (StreamWriter file = new StreamWriter(caminho))
            {
                while (reader.Read())
                {
                    string linha = string.Empty;
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        linha += $@"{reader[i]};";
                    }
                    file.WriteLine(linha);
                }
            }
        }
        
        public void SalvarGeracaoArquivo()
        {
            ExporterContexto contexto = new ExporterContexto();
            using (contexto)
            {
                using (var dbContextTransaction = contexto.Database.BeginTransaction())
                {
                    try
                    {
                        contexto.ExecucaoRelatorio.Add(new ExecucaoRelatorio
                        {
                            nome = relatorio.Name,
                            consulta = relatorio.GetSqlRelatorio(),
                            dataExecucao = DateTime.Now,
                        });
                        contexto.SaveChanges();
                        dbContextTransaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
