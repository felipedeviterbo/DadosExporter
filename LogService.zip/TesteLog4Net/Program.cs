﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TesteLog4Net
{
    class Program
    {
        private static ILog FileLog = LogManager.GetLogger("FileAppender");
        private static readonly ILog Eventlog = LogManager.GetLogger("EventLogAppender");
        static void Main(string[] args)
        {
            Console.WriteLine("Inserindo log");
            FileLog.Error("Log de arquiov");
            Eventlog.Error("SOFMASOMFASOMFASOM");
            Console.ReadKey();
        }
    }
}
