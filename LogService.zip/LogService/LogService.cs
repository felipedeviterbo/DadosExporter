﻿using log4net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace LogService
{
    public partial class LogService : ServiceBase
    {
        private static ILog Log = LogManager.GetLogger("EventLogAppender");//LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        public LogService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Log.Debug("Started");
            string file = string.Format(@"D:\WorkspacePessoal\WindowsService\LogService\Files\TT_INIT_{0}.txt", DateTime.Now.ToString("ddMMyyyyHHmmss"));
            File.WriteAllText(file, "TESTE");
        }

        protected override void OnStop()
        {
            Log.Debug("Stop");
            string file = string.Format(@"D:\WorkspacePessoal\WindowsService\LogService\Files\TT_STOP_{0}.txt", DateTime.Now.ToString("DDMMYYYYHHMM"));
            File.WriteAllText(file, "TESTE");
        }

        protected override void OnContinue()
        {
            Log.Debug("Continue");
            string file = string.Format(@"D:\WorkspacePessoal\WindowsService\LogService\Files\TT_CONT_{0}.txt", DateTime.Now.ToString("DDMMYYYYHHMM"));
            File.WriteAllText(file, "OSMAFOAMS");
        }
    }
}
