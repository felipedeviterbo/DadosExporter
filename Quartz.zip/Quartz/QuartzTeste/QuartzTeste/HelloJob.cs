﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quartz;

namespace QuartzTeste
{
    public class HelloJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            try
            {
                Console.WriteLine($@"HelloJob is executing{DateTime.Now.ToString("ddmmyyyyhhmmss")}.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro is executing.");
            }
        }
    }
}
